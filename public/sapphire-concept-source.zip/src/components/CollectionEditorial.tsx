import React from 'react';
import { motion } from 'motion/react';
import { ArrowUpRight } from 'lucide-react';
import { EDITORIAL_COLLECTIONS } from '../data/product';

interface CollectionEditorialProps {
  onSelectStory: (storyId: string) => void;
}

export const CollectionEditorial: React.FC<CollectionEditorialProps> = ({ onSelectStory }) => {
  return (
    <section
      id="section-collections"
      className="relative py-28 md:py-44 px-6 sm:px-10 md:px-14 bg-[#F4F1EA] border-t border-[#0B0A0A]/10 overflow-hidden text-[#0B0A0A]"
    >
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-20 md:mb-32 pb-6 border-b border-[#0B0A0A]/10 gap-8">
          <div className="space-y-3">
            <span className="text-[10px] tracking-[0.35em] uppercase font-sans text-[#8A857D] block">
              Chapter 03 — Anthology
            </span>
            <h2 className="font-serif text-4xl sm:text-6xl md:text-7xl font-normal tracking-tight text-[#0B0A0A]">
              The Curated <span className="italic font-light text-[#8A857D]">Series.</span>
            </h2>
          </div>
          <p className="max-w-sm text-xs sm:text-sm font-sans font-light text-[#1E1D1C]/75 leading-relaxed">
            Rejecting transient fast-fashion cycles in pursuit of heirloom garments and sculpted
            accessories engineered to endure generations.
          </p>
        </div>

        {/* Editorial Story Blocks with High-End Asymmetry */}
        <div className="space-y-32 md:space-y-48">
          {EDITORIAL_COLLECTIONS.map((col, idx) => {
            const isEven = idx % 2 === 1;

            return (
              <motion.div
                key={col.id}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-90px' }}
                transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
                className={`grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-16 items-center ${
                  isEven ? 'lg:grid-flow-dense' : ''
                }`}
              >
                {/* Visual Block with Architectural Proportion */}
                <div
                  className={`relative group overflow-hidden bg-[#ECE7DE] cursor-pointer ${
                    isEven ? 'lg:col-span-7 lg:col-start-6' : 'lg:col-span-7'
                  }`}
                  onClick={() => onSelectStory(col.id)}
                >
                  <div className="aspect-[4/5] sm:aspect-[16/11] w-full overflow-hidden">
                    <img
                      src={col.image}
                      alt={col.title}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover object-center transition-transform duration-1000 ease-out group-hover:scale-103 filter contrast-[1.03]"
                    />
                  </div>

                  {/* Micro Metadata Tag */}
                  <div className="absolute top-5 left-5 bg-[#0B0A0A]/75 backdrop-blur-xs text-[#FAF8F5] px-3 py-1 text-[8px] tracking-[0.3em] uppercase font-sans">
                    {col.category}
                  </div>
                </div>

                {/* Typography Block */}
                <div
                  className={`flex flex-col justify-center space-y-6 ${
                    isEven ? 'lg:col-span-5 lg:col-start-1' : 'lg:col-span-5'
                  }`}
                >
                  <div className="flex items-center gap-3 text-[10px] tracking-[0.3em] uppercase font-sans text-[#8A857D]">
                    <span>Plate 0{idx + 1}</span>
                    <span>·</span>
                    <span>{col.edition}</span>
                  </div>

                  <h3 className="font-serif text-3xl sm:text-4xl md:text-5xl text-[#0B0A0A] font-normal leading-tight">
                    {col.title}
                  </h3>

                  <p className="text-xs sm:text-sm font-sans font-light text-[#1E1D1C]/80 leading-relaxed max-w-md">
                    {col.description}
                  </p>

                  <div className="pt-2">
                    <button
                      type="button"
                      onClick={() => onSelectStory(col.id)}
                      className="group inline-flex items-center gap-2.5 text-[11px] tracking-[0.25em] uppercase font-sans font-medium text-[#0B0A0A] pb-1 border-b border-[#0B0A0A]/30 hover:border-[#0B0A0A] transition-colors"
                    >
                      <span>Read Lookbook</span>
                      <ArrowUpRight className="w-3.5 h-3.5 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                    </button>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
