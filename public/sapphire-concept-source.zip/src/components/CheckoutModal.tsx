import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Check, ShieldCheck, Truck, ArrowRight } from 'lucide-react';
import { CartItem } from '../types';

interface CheckoutModalProps {
  isOpen: boolean;
  items: CartItem[];
  onClose: () => void;
  onOrderComplete: () => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  items,
  onClose,
  onOrderComplete,
}) => {
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [city, setCity] = useState('Lahore');
  const [address, setAddress] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'cod' | 'card'>('card');
  const [isProcessing, setIsProcessing] = useState(false);
  const [orderSuccess, setOrderSuccess] = useState(false);
  const [orderRef, setOrderRef] = useState('');

  const subtotal = items.reduce(
    (sum, item) => sum + item.product.price * item.quantity,
    0
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      setOrderRef(`SPH-${Math.floor(100000 + Math.random() * 900000)}`);
      setOrderSuccess(true);
      onOrderComplete();
    }, 800);
  };

  const handleFinish = () => {
    setOrderSuccess(false);
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div id="checkout-modal-container" className="fixed inset-0 z-50 overflow-y-auto">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-[#0B0A0A]/60 backdrop-blur-xs"
          />

          {/* Modal Content */}
          <div className="min-h-full flex items-center justify-center p-4 sm:p-6 relative">
            <motion.div
              initial={{ opacity: 0, scale: 0.98, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.98, y: 15 }}
              transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
              className="relative w-full max-w-xl bg-[#FAF8F5] text-[#0B0A0A] shadow-2xl p-6 sm:p-10 border border-[#0B0A0A]/10"
            >
              {/* Close Button */}
              <button
                type="button"
                onClick={onClose}
                aria-label="Close checkout"
                className="absolute top-6 right-6 p-1.5 text-[#0B0A0A] hover:opacity-50 transition-opacity"
              >
                <X className="w-4 h-4" />
              </button>

              {orderSuccess ? (
                <div className="py-8 text-center space-y-6">
                  <div className="w-12 h-12 rounded-full bg-[#1C3B2B] text-[#FAF8F5] flex items-center justify-center mx-auto shadow-sm">
                    <Check className="w-6 h-6" />
                  </div>
                  <div className="space-y-2">
                    <span className="text-[9px] tracking-[0.35em] uppercase font-sans text-[#8A857D]">
                      Acquisition Confirmed
                    </span>
                    <h3 className="font-serif text-3xl sm:text-4xl text-[#0B0A0A]">
                      Thank You, {fullName || 'Valued Patron'}
                    </h3>
                    <p className="text-xs tracking-widest font-sans text-[#8A857D]">
                      Reference Code: <strong className="text-[#0B0A0A]">{orderRef}</strong>
                    </p>
                  </div>

                  <p className="text-xs sm:text-sm font-sans font-light text-[#1E1D1C]/80 max-w-md mx-auto leading-relaxed">
                    Your bespoke shipment has been registered at our Lahore atelier. A private
                    concierge has dispatched confirmation details and secure courier tracking.
                  </p>

                  <div className="pt-3">
                    <button
                      type="button"
                      onClick={handleFinish}
                      className="px-8 py-3 bg-[#0B0A0A] text-[#FAF8F5] text-[11px] tracking-[0.25em] uppercase font-sans font-medium hover:bg-[#232220] transition-colors"
                    >
                      Return to Lookbook
                    </button>
                  </div>
                </div>
              ) : (
                <div className="space-y-8">
                  {/* Header */}
                  <div>
                    <span className="text-[9px] tracking-[0.35em] uppercase font-sans text-[#8A857D]">
                      Private Atelier Concierge
                    </span>
                    <h3 className="font-serif text-3xl text-[#0B0A0A] pt-1">
                      Complete Acquisition
                    </h3>
                  </div>

                  <form onSubmit={handleSubmit} className="space-y-6">
                    {/* Items brief */}
                    <div className="bg-[#F4F1EA] p-4 text-xs font-sans flex justify-between items-center">
                      <div>
                        <span className="font-medium text-[#0B0A0A]">
                          {items.reduce((sum, i) => sum + i.quantity, 0)} Archive Selection(s)
                        </span>
                        <p className="text-[10px] text-[#8A857D] mt-0.5">Complimentary Insured Courier</p>
                      </div>
                      <span className="font-serif text-lg text-[#0B0A0A]">
                        PKR {subtotal.toLocaleString()}
                      </span>
                    </div>

                    {/* Inputs */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-sans">
                      <div>
                        <label className="block text-[9px] tracking-[0.25em] uppercase text-[#8A857D] mb-1">
                          Full Name
                        </label>
                        <input
                          type="text"
                          required
                          value={fullName}
                          onChange={(e) => setFullName(e.target.value)}
                          placeholder="e.g. Ayla Khan"
                          className="w-full p-2.5 bg-transparent border border-[#0B0A0A]/20 focus:border-[#0B0A0A] outline-none"
                        />
                      </div>

                      <div>
                        <label className="block text-[9px] tracking-[0.25em] uppercase text-[#8A857D] mb-1">
                          Contact Phone
                        </label>
                        <input
                          type="tel"
                          required
                          value={phone}
                          onChange={(e) => setPhone(e.target.value)}
                          placeholder="+92 300 1234567"
                          className="w-full p-2.5 bg-transparent border border-[#0B0A0A]/20 focus:border-[#0B0A0A] outline-none"
                        />
                      </div>

                      <div>
                        <label className="block text-[9px] tracking-[0.25em] uppercase text-[#8A857D] mb-1">
                          City
                        </label>
                        <select
                          value={city}
                          onChange={(e) => setCity(e.target.value)}
                          className="w-full p-2.5 bg-transparent border border-[#0B0A0A]/20 focus:border-[#0B0A0A] outline-none text-[#0B0A0A]"
                        >
                          <option value="Lahore">Lahore</option>
                          <option value="Karachi">Karachi</option>
                          <option value="Islamabad">Islamabad</option>
                          <option value="Rawalpindi">Rawalpindi</option>
                          <option value="Faisalabad">Faisalabad</option>
                          <option value="Peshawar">Peshawar</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-[9px] tracking-[0.25em] uppercase text-[#8A857D] mb-1">
                          Payment Mode
                        </label>
                        <div className="grid grid-cols-2 gap-2 h-[41px]">
                          <button
                            type="button"
                            onClick={() => setPaymentMethod('card')}
                            className={`px-2 text-[9px] tracking-wider uppercase border transition-colors ${
                              paymentMethod === 'card'
                                ? 'bg-[#0B0A0A] text-[#FAF8F5] border-[#0B0A0A]'
                                : 'border-[#0B0A0A]/20 text-[#0B0A0A]'
                            }`}
                          >
                            Card / Online
                          </button>
                          <button
                            type="button"
                            onClick={() => setPaymentMethod('cod')}
                            className={`px-2 text-[9px] tracking-wider uppercase border transition-colors ${
                              paymentMethod === 'cod'
                                ? 'bg-[#0B0A0A] text-[#FAF8F5] border-[#0B0A0A]'
                                : 'border-[#0B0A0A]/20 text-[#0B0A0A]'
                            }`}
                          >
                            White Glove COD
                          </button>
                        </div>
                      </div>

                      <div className="sm:col-span-2">
                        <label className="block text-[9px] tracking-[0.25em] uppercase text-[#8A857D] mb-1">
                          Delivery Address
                        </label>
                        <input
                          type="text"
                          required
                          value={address}
                          onChange={(e) => setAddress(e.target.value)}
                          placeholder="House / Apartment, Street, Phase / Sector"
                          className="w-full p-2.5 bg-transparent border border-[#0B0A0A]/20 focus:border-[#0B0A0A] outline-none"
                        />
                      </div>
                    </div>

                    {/* Submit Button */}
                    <button
                      id="submit-order-btn"
                      type="submit"
                      disabled={isProcessing}
                      className="w-full py-3.5 bg-[#0B0A0A] text-[#FAF8F5] text-[11px] tracking-[0.25em] uppercase font-sans font-medium transition-colors hover:bg-[#232220] flex items-center justify-center gap-3"
                    >
                      {isProcessing ? (
                        <div className="flex items-center gap-2">
                          <span className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                          <span>Authorizing Order...</span>
                        </div>
                      ) : (
                        <>
                          <span>Authorize Acquisition · PKR {subtotal.toLocaleString()}</span>
                          <ArrowRight className="w-3.5 h-3.5" />
                        </>
                      )}
                    </button>

                    <div className="flex items-center justify-center gap-6 text-[9px] tracking-wider uppercase font-sans text-[#8A857D] pt-2">
                      <div className="flex items-center gap-1.5">
                        <ShieldCheck className="w-3 h-3 text-[#0B0A0A]" />
                        <span>Insured Delivery</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <Truck className="w-3 h-3 text-[#0B0A0A]" />
                        <span>Dispatched from Lahore Atelier</span>
                      </div>
                    </div>
                  </form>
                </div>
              )}
            </motion.div>
          </div>
        </div>
      )}
    </AnimatePresence>
  );
};
