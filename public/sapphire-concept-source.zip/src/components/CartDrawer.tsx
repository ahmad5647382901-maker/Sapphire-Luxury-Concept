import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Plus, Minus, Trash2, ArrowRight, ShieldCheck, ShoppingBag } from 'lucide-react';
import { CartItem } from '../types';

interface CartDrawerProps {
  isOpen: boolean;
  items: CartItem[];
  onClose: () => void;
  onUpdateQuantity: (productId: string, quantity: number) => void;
  onRemoveItem: (productId: string) => void;
  onGoToCheckout: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  items,
  onClose,
  onUpdateQuantity,
  onRemoveItem,
  onGoToCheckout,
}) => {
  const subtotal = items.reduce(
    (sum, item) => sum + item.product.price * item.quantity,
    0
  );

  return (
    <AnimatePresence>
      {isOpen && (
        <div id="cart-drawer-container" className="fixed inset-0 z-50 overflow-hidden">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.35 }}
            onClick={onClose}
            className="absolute inset-0 bg-[#0B0A0A]/60 backdrop-blur-xs"
          />

          {/* Drawer Panel */}
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
            className="absolute inset-y-0 right-0 max-w-md w-full bg-[#FAF8F5] text-[#0B0A0A] shadow-2xl flex flex-col justify-between"
          >
            {/* Top Bar */}
            <div className="p-6 sm:p-8 border-b border-[#0B0A0A]/10 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <ShoppingBag className="w-4 h-4 text-[#0B0A0A]" />
                <h2 className="font-serif text-xl tracking-[0.1em] text-[#0B0A0A] uppercase font-light">
                  Bag ({items.reduce((s, i) => s + i.quantity, 0)})
                </h2>
              </div>
              <button
                id="close-cart-drawer"
                type="button"
                onClick={onClose}
                aria-label="Close bag"
                className="p-1 text-[#0B0A0A] hover:opacity-50 transition-opacity"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Items List or Empty State */}
            <div className="flex-1 overflow-y-auto p-6 sm:p-8 space-y-6">
              {items.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center space-y-4 py-20">
                  <div className="w-12 h-12 rounded-full bg-[#F4F1EA] flex items-center justify-center text-[#8A857D]">
                    <ShoppingBag className="w-5 h-5" />
                  </div>
                  <h3 className="font-serif text-2xl text-[#0B0A0A] font-normal">Your bag is empty</h3>
                  <p className="text-xs font-sans font-light text-[#8A857D] max-w-xs leading-relaxed">
                    Explore our architectural leather silhouettes and limited edition series.
                  </p>
                  <button
                    type="button"
                    onClick={onClose}
                    className="mt-2 text-[10px] tracking-[0.25em] uppercase font-sans font-medium text-[#0B0A0A] border-b border-[#0B0A0A] pb-0.5"
                  >
                    Return to Collection
                  </button>
                </div>
              ) : (
                items.map((item) => (
                  <div
                    key={item.product.id}
                    className="flex gap-4 border-b border-[#0B0A0A]/10 pb-6"
                  >
                    {/* Item Image */}
                    <div className="w-20 h-24 bg-[#F4F1EA] overflow-hidden shrink-0">
                      <img
                        src={item.product.images[0].url}
                        alt={item.product.name}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover object-center"
                      />
                    </div>

                    {/* Details */}
                    <div className="flex-1 flex flex-col justify-between">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <h4 className="font-serif text-base text-[#0B0A0A] leading-tight">
                            {item.product.name}
                          </h4>
                          <p className="text-[10px] tracking-[0.2em] uppercase font-sans text-[#8A857D] mt-1">
                            {item.selectedColor}
                          </p>
                        </div>
                        <button
                          type="button"
                          onClick={() => onRemoveItem(item.product.id)}
                          aria-label="Remove item"
                          className="text-[#8A857D] hover:text-[#0B0A0A] transition-colors p-1"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div className="flex items-center justify-between pt-2">
                        {/* Quantity Stepper */}
                        <div className="flex items-center border border-[#0B0A0A]/20 bg-[#FAF8F5]">
                          <button
                            type="button"
                            onClick={() => onUpdateQuantity(item.product.id, item.quantity - 1)}
                            className="px-2 py-1 text-[#0B0A0A] hover:bg-[#0B0A0A]/5"
                          >
                            <Minus className="w-2.5 h-2.5" />
                          </button>
                          <span className="w-6 text-center text-xs font-sans font-medium">
                            {item.quantity}
                          </span>
                          <button
                            type="button"
                            onClick={() => onUpdateQuantity(item.product.id, item.quantity + 1)}
                            className="px-2 py-1 text-[#0B0A0A] hover:bg-[#0B0A0A]/5"
                          >
                            <Plus className="w-2.5 h-2.5" />
                          </button>
                        </div>

                        {/* Price */}
                        <span className="font-serif text-sm text-[#0B0A0A]">
                          PKR {(item.product.price * item.quantity).toLocaleString()}
                        </span>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Bottom Summary & Checkout */}
            {items.length > 0 && (
              <div className="p-6 sm:p-8 border-t border-[#0B0A0A]/10 bg-[#F4F1EA] space-y-4">
                <div className="space-y-2 text-xs font-sans font-light">
                  <div className="flex justify-between text-[#1E1D1C]/75">
                    <span>Subtotal</span>
                    <span>PKR {subtotal.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-[#1E1D1C]/75">
                    <span>Delivery (Pakistan)</span>
                    <span className="text-[#0B0A0A] font-normal">Complimentary</span>
                  </div>
                  <div className="flex justify-between text-xs font-sans font-medium text-[#0B0A0A] pt-2 border-t border-[#0B0A0A]/10">
                    <span>Total Order</span>
                    <span className="font-serif text-base">PKR {subtotal.toLocaleString()}</span>
                  </div>
                </div>

                <button
                  id="checkout-cta-button"
                  type="button"
                  onClick={onGoToCheckout}
                  className="w-full py-3.5 bg-[#0B0A0A] text-[#FAF8F5] text-[11px] tracking-[0.25em] uppercase font-sans font-medium transition-colors hover:bg-[#232220] flex items-center justify-center gap-3"
                >
                  <span>Proceed to Checkout</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>

                <div className="flex items-center justify-center gap-2 text-[9px] tracking-[0.2em] uppercase font-sans text-[#8A857D] text-center">
                  <ShieldCheck className="w-3 h-3 text-[#0B0A0A]" />
                  <span>Insured White-Glove Hand Courier</span>
                </div>
              </div>
            )}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
