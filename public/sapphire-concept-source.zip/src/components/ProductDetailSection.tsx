import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Heart,
  Plus,
  Minus,
  Check,
  ChevronDown,
  Maximize2,
  ChevronLeft,
  ChevronRight,
  ShieldCheck,
  Truck,
} from 'lucide-react';
import { Product } from '../types';

interface ProductDetailSectionProps {
  product: Product;
  isInWishlist: boolean;
  onToggleWishlist: () => void;
  onAddToCart: (quantity: number) => void;
}

export const ProductDetailSection: React.FC<ProductDetailSectionProps> = ({
  product,
  isInWishlist,
  onToggleWishlist,
  onAddToCart,
}) => {
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [isAdding, setIsAdding] = useState(false);
  const [addedSuccess, setAddedSuccess] = useState(false);
  const [openAccordion, setOpenAccordion] = useState<string | null>('details');

  // Desktop hover zoom state
  const [isHovered, setIsHovered] = useState(false);
  const [mousePosition, setMousePosition] = useState({ x: 50, y: 50 });
  const imageContainerRef = useRef<HTMLDivElement>(null);

  // Mobile touch swipe
  const touchStartXRef = useRef<number | null>(null);
  const touchEndXRef = useRef<number | null>(null);

  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartXRef.current = e.targetTouches[0].clientX;
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    touchEndXRef.current = e.targetTouches[0].clientX;
  };

  const handleTouchEnd = () => {
    if (!touchStartXRef.current || !touchEndXRef.current) return;
    const distance = touchStartXRef.current - touchEndXRef.current;
    if (distance > 40) {
      setSelectedImageIndex((prev) => (prev + 1) % product.images.length);
    } else if (distance < -40) {
      setSelectedImageIndex((prev) => (prev - 1 + product.images.length) % product.images.length);
    }
    touchStartXRef.current = null;
    touchEndXRef.current = null;
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!imageContainerRef.current) return;
    const rect = imageContainerRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    setMousePosition({ x, y });
  };

  const handleAdd = () => {
    setIsAdding(true);
    setTimeout(() => {
      onAddToCart(quantity);
      setIsAdding(false);
      setAddedSuccess(true);
      setTimeout(() => setAddedSuccess(false), 2400);
    }, 400);
  };

  const currentImage = product.images[selectedImageIndex];

  const toggleAccordion = (id: string) => {
    setOpenAccordion((prev) => (prev === id ? null : id));
  };

  return (
    <section
      id="section-product-detail"
      className="relative py-28 md:py-44 px-6 sm:px-10 md:px-14 bg-[#FAF8F5] border-t border-[#0B0A0A]/10 text-[#0B0A0A]"
    >
      <div className="max-w-7xl mx-auto">
        {/* Editorial Subheader */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-5 border-b border-[#0B0A0A]/10 mb-14 md:mb-20 gap-4 text-[10px] tracking-[0.3em] uppercase font-sans text-[#8A857D]">
          <div className="flex items-center gap-3">
            <span>Chapter 06</span>
            <span>·</span>
            <span className="text-[#0B0A0A]">Archive Reference SAP-2026-N01</span>
          </div>

          <div className="flex items-center gap-6">
            <span className="hidden sm:inline">Complimentary Pakistan Insured Courier</span>
            <button
              type="button"
              id="inspect-rear-view-btn"
              onClick={() => setSelectedImageIndex(2)}
              className="text-[#0B0A0A] pb-0.5 border-b border-[#0B0A0A] hover:opacity-60 transition-opacity"
            >
              Direct Rear Elevation
            </button>
          </div>
        </div>

        {/* Product Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-20 items-start">
          {/* LEFT: Product Image Gallery */}
          <div className="lg:col-span-7 flex flex-col space-y-6">
            {/* Cinematic Main Image Stage */}
            <div
              ref={imageContainerRef}
              id="main-product-image-container"
              onMouseEnter={() => setIsHovered(true)}
              onMouseLeave={() => setIsHovered(false)}
              onMouseMove={handleMouseMove}
              onTouchStart={handleTouchStart}
              onTouchMove={handleTouchMove}
              onTouchEnd={handleTouchEnd}
              className="relative aspect-[4/5] sm:aspect-[1/1] w-full overflow-hidden bg-[#F4F1EA] select-none cursor-crosshair group"
            >
              <AnimatePresence mode="wait">
                <motion.div
                  key={currentImage.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
                  className="w-full h-full relative"
                >
                  <img
                    src={currentImage.url}
                    alt={currentImage.alt}
                    referrerPolicy="no-referrer"
                    style={{
                      transformOrigin: `${mousePosition.x}% ${mousePosition.y}%`,
                      transform: isHovered ? 'scale(1.22)' : 'scale(1)',
                      transition: isHovered ? 'transform 0.1s ease-out' : 'transform 0.5s ease-out',
                    }}
                    className="w-full h-full object-cover object-center pointer-events-none"
                  />
                </motion.div>
              </AnimatePresence>

              {/* View Label & Minimal Counter */}
              <div className="absolute top-6 left-6 flex items-center gap-3 pointer-events-none z-10">
                <div className="bg-[#FAF8F5]/90 backdrop-blur-xs px-3 py-1 text-[9px] tracking-[0.25em] uppercase font-sans text-[#0B0A0A]">
                  {currentImage.viewName}
                </div>
                <div className="bg-[#0B0A0A] text-[#FAF8F5] px-2.5 py-1 text-[9px] tracking-[0.2em] font-sans">
                  {currentImage.label}
                </div>
              </div>

              {/* Rear Elevation Note */}
              {selectedImageIndex === 2 && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="absolute bottom-6 left-6 bg-[#0B0A0A]/85 backdrop-blur-xs text-[#FAF8F5] px-3.5 py-1.5 text-[9px] tracking-[0.25em] uppercase font-sans pointer-events-none z-10"
                >
                  Rear Panel · Flush Slip Pocket & Saddle Stitching
                </motion.div>
              )}

              {/* Mobile Arrows */}
              <div className="absolute inset-y-0 left-0 right-0 flex items-center justify-between px-3 pointer-events-none sm:hidden z-10">
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setSelectedImageIndex((prev) => (prev - 1 + product.images.length) % product.images.length);
                  }}
                  aria-label="Previous view"
                  className="pointer-events-auto p-2 bg-[#FAF8F5]/90 text-[#0B0A0A] shadow-sm hover:bg-[#FAF8F5]"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setSelectedImageIndex((prev) => (prev + 1) % product.images.length);
                  }}
                  aria-label="Next view"
                  className="pointer-events-auto p-2 bg-[#FAF8F5]/90 text-[#0B0A0A] shadow-sm hover:bg-[#FAF8F5]"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>

              {/* Desktop Zoom Indicator */}
              <div className="absolute bottom-6 right-6 hidden md:flex items-center gap-2 text-[9px] tracking-[0.25em] uppercase font-sans text-[#8A857D] bg-[#FAF8F5]/80 px-3 py-1 pointer-events-none">
                <Maximize2 className="w-3 h-3 text-[#0B0A0A]" />
                <span>Hover to inspect calfskin</span>
              </div>
            </div>

            {/* Four Elegant Gallery Thumbnails */}
            <div className="grid grid-cols-4 gap-3 md:gap-4">
              {product.images.map((img, idx) => {
                const isActive = selectedImageIndex === idx;

                return (
                  <button
                    key={img.id}
                    id={`gallery-thumb-${idx}`}
                    type="button"
                    onClick={() => setSelectedImageIndex(idx)}
                    className={`relative group flex flex-col text-left transition-opacity duration-300 ${
                      isActive ? 'opacity-100' : 'opacity-50 hover:opacity-85'
                    }`}
                  >
                    <div
                      className={`relative aspect-[1/1] w-full overflow-hidden bg-[#F4F1EA] transition-all duration-300 ${
                        isActive ? 'ring-1 ring-[#0B0A0A]' : ''
                      }`}
                    >
                      <img
                        src={img.url}
                        alt={img.alt}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover object-center"
                      />
                    </div>
                    <div className="mt-2 flex items-center justify-between text-[9px] font-sans tracking-[0.2em] uppercase text-[#0B0A0A]">
                      <span className="truncate">{img.viewName.split(' ')[0]}</span>
                      <span className="text-[#8A857D]">{img.label.split(' / ')[0]}</span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* RIGHT: Product Information & Purchase */}
          <div className="lg:col-span-5 flex flex-col space-y-8">
            {/* Header Titles */}
            <div className="space-y-3">
              <span className="text-[9px] tracking-[0.35em] uppercase font-sans text-[#8A857D] block">
                The Masterwork Bag
              </span>
              <h1 className="font-serif text-4xl sm:text-5xl md:text-6xl text-[#0B0A0A] font-normal leading-[0.98]">
                {product.name}
              </h1>
              <div className="flex items-baseline gap-4 pt-2">
                <span className="font-serif text-3xl sm:text-4xl text-[#0B0A0A]">
                  {product.formattedPrice}
                </span>
                <span className="text-[10px] tracking-[0.25em] uppercase font-sans text-[#8A857D]">
                  Duties & Delivery Included
                </span>
              </div>
            </div>

            {/* Description Statement */}
            <p className="text-xs sm:text-sm font-sans font-light text-[#1E1D1C]/80 leading-relaxed border-l border-[#0B0A0A] pl-4">
              {product.description}
            </p>

            {/* Color Selector */}
            <div className="space-y-2 pt-2">
              <div className="flex items-center justify-between text-[10px] tracking-[0.25em] uppercase font-sans">
                <span className="font-medium text-[#0B0A0A]">Colorway</span>
                <span className="text-[#8A857D]">{product.color}</span>
              </div>
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  aria-label="Noir Black"
                  className="w-6 h-6 rounded-full bg-[#111111] ring-1 ring-offset-2 ring-offset-[#FAF8F5] ring-[#0B0A0A]"
                />
                <span className="text-xs font-sans text-[#8A857D]">
                  Hand-Curated Noir Calfskin
                </span>
              </div>
            </div>

            {/* Quantity Selector & Action Controls */}
            <div className="space-y-4 pt-2">
              <div className="flex items-center gap-4">
                <span className="text-[10px] tracking-[0.25em] uppercase font-sans font-medium text-[#0B0A0A]">
                  Quantity
                </span>
                <div className="flex items-center border border-[#0B0A0A]/20 bg-[#FAF8F5]">
                  <button
                    type="button"
                    onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                    aria-label="Decrease quantity"
                    className="px-3 py-2 text-[#0B0A0A] hover:bg-[#0B0A0A]/5 transition-colors"
                  >
                    <Minus className="w-3 h-3" />
                  </button>
                  <span className="w-8 text-center text-xs font-sans font-medium text-[#0B0A0A]">
                    {quantity}
                  </span>
                  <button
                    type="button"
                    onClick={() => setQuantity((q) => Math.min(5, q + 1))}
                    aria-label="Increase quantity"
                    className="px-3 py-2 text-[#0B0A0A] hover:bg-[#0B0A0A]/5 transition-colors"
                  >
                    <Plus className="w-3 h-3" />
                  </button>
                </div>
              </div>

              {/* Add to Bag & Wishlist Buttons */}
              <div className="flex items-center gap-3 pt-2">
                <button
                  id="add-to-bag-button"
                  type="button"
                  onClick={handleAdd}
                  disabled={isAdding}
                  className={`flex-1 relative overflow-hidden h-13 flex items-center justify-center text-[11px] tracking-[0.25em] uppercase font-sans font-medium transition-all duration-300 ${
                    addedSuccess
                      ? 'bg-[#1C3B2B] text-[#FAF8F5]'
                      : 'bg-[#0B0A0A] text-[#FAF8F5] hover:bg-[#232220]'
                  }`}
                >
                  <AnimatePresence mode="wait">
                    {addedSuccess ? (
                      <motion.div
                        key="added"
                        initial={{ opacity: 0, y: 6 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -6 }}
                        className="flex items-center gap-2"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>Secured to Bag</span>
                      </motion.div>
                    ) : isAdding ? (
                      <motion.div
                        key="adding"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="flex items-center gap-2"
                      >
                        <span className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                        <span>Securing Item...</span>
                      </motion.div>
                    ) : (
                      <motion.div
                        key="idle"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="flex items-center gap-2"
                      >
                        <span>Add to Bag</span>
                        <span className="text-[#FAF8F5]/40">·</span>
                        <span>PKR {(product.price * quantity).toLocaleString()}</span>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </button>

                <button
                  id="wishlist-toggle-btn"
                  type="button"
                  onClick={onToggleWishlist}
                  aria-label={isInWishlist ? 'Remove from Wishlist' : 'Add to Wishlist'}
                  className={`h-13 w-13 flex items-center justify-center border transition-all duration-300 ${
                    isInWishlist
                      ? 'border-[#0B0A0A] bg-[#0B0A0A] text-[#FAF8F5]'
                      : 'border-[#0B0A0A]/20 text-[#0B0A0A] hover:border-[#0B0A0A]'
                  }`}
                >
                  <Heart className={`w-4 h-4 ${isInWishlist ? 'fill-current' : ''}`} />
                </button>
              </div>
            </div>

            {/* Quick Guarantees */}
            <div className="grid grid-cols-2 gap-4 pt-4 border-t border-[#0B0A0A]/10 text-[10px] tracking-[0.2em] uppercase font-sans text-[#8A857D]">
              <div className="flex items-center gap-2">
                <Truck className="w-3.5 h-3.5 text-[#0B0A0A]" />
                <span>Complimentary Delivery</span>
              </div>
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-3.5 h-3.5 text-[#0B0A0A]" />
                <span>Serialized Authentication</span>
              </div>
            </div>

            {/* Editorial Accordions */}
            <div className="border-t border-[#0B0A0A]/10 divide-y divide-[#0B0A0A]/10 pt-1">
              {/* Product Details */}
              <div className="py-4">
                <button
                  type="button"
                  onClick={() => toggleAccordion('details')}
                  className="w-full flex items-center justify-between text-left text-[10px] tracking-[0.25em] uppercase font-sans font-medium text-[#0B0A0A]"
                >
                  <span>Product Details</span>
                  <ChevronDown
                    className={`w-3.5 h-3.5 transition-transform duration-300 ${
                      openAccordion === 'details' ? 'rotate-180' : ''
                    }`}
                  />
                </button>
                <AnimatePresence>
                  {openAccordion === 'details' && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.3 }}
                      className="overflow-hidden"
                    >
                      <ul className="pt-3 space-y-2 text-xs font-sans font-light text-[#1E1D1C]/80 leading-relaxed list-disc list-inside">
                        {product.details.map((item, idx) => (
                          <li key={idx}>{item}</li>
                        ))}
                      </ul>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* Materials */}
              <div className="py-4">
                <button
                  type="button"
                  onClick={() => toggleAccordion('materials')}
                  className="w-full flex items-center justify-between text-left text-[10px] tracking-[0.25em] uppercase font-sans font-medium text-[#0B0A0A]"
                >
                  <span>Materials & Origins</span>
                  <ChevronDown
                    className={`w-3.5 h-3.5 transition-transform duration-300 ${
                      openAccordion === 'materials' ? 'rotate-180' : ''
                    }`}
                  />
                </button>
                <AnimatePresence>
                  {openAccordion === 'materials' && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.3 }}
                      className="overflow-hidden"
                    >
                      <ul className="pt-3 space-y-2 text-xs font-sans font-light text-[#1E1D1C]/80 leading-relaxed list-disc list-inside">
                        {product.materials.map((mat, idx) => (
                          <li key={idx}>{mat}</li>
                        ))}
                      </ul>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* Dimensions */}
              <div className="py-4">
                <button
                  type="button"
                  onClick={() => toggleAccordion('dimensions')}
                  className="w-full flex items-center justify-between text-left text-[10px] tracking-[0.25em] uppercase font-sans font-medium text-[#0B0A0A]"
                >
                  <span>Dimensions & Fit</span>
                  <ChevronDown
                    className={`w-3.5 h-3.5 transition-transform duration-300 ${
                      openAccordion === 'dimensions' ? 'rotate-180' : ''
                    }`}
                  />
                </button>
                <AnimatePresence>
                  {openAccordion === 'dimensions' && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.3 }}
                      className="overflow-hidden"
                    >
                      <div className="pt-3 space-y-2 text-xs font-sans font-light text-[#1E1D1C]/80">
                        <p><strong className="text-[#0B0A0A] font-medium">Height:</strong> {product.dimensions.height}</p>
                        <p><strong className="text-[#0B0A0A] font-medium">Width:</strong> {product.dimensions.width}</p>
                        <p><strong className="text-[#0B0A0A] font-medium">Depth:</strong> {product.dimensions.depth}</p>
                        <p><strong className="text-[#0B0A0A] font-medium">Strap Drop:</strong> {product.dimensions.strapDrop}</p>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* Shipping */}
              <div className="py-4">
                <button
                  type="button"
                  onClick={() => toggleAccordion('shipping')}
                  className="w-full flex items-center justify-between text-left text-[10px] tracking-[0.25em] uppercase font-sans font-medium text-[#0B0A0A]"
                >
                  <span>Shipping & Courier</span>
                  <ChevronDown
                    className={`w-3.5 h-3.5 transition-transform duration-300 ${
                      openAccordion === 'shipping' ? 'rotate-180' : ''
                    }`}
                  />
                </button>
                <AnimatePresence>
                  {openAccordion === 'shipping' && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.3 }}
                      className="overflow-hidden"
                    >
                      <p className="pt-3 text-xs font-sans font-light text-[#1E1D1C]/80 leading-relaxed">
                        {product.shippingInfo}
                      </p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* Returns */}
              <div className="py-4">
                <button
                  type="button"
                  onClick={() => toggleAccordion('returns')}
                  className="w-full flex items-center justify-between text-left text-[10px] tracking-[0.25em] uppercase font-sans font-medium text-[#0B0A0A]"
                >
                  <span>Exchange & Archive Policy</span>
                  <ChevronDown
                    className={`w-3.5 h-3.5 transition-transform duration-300 ${
                      openAccordion === 'returns' ? 'rotate-180' : ''
                    }`}
                  />
                </button>
                <AnimatePresence>
                  {openAccordion === 'returns' && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.3 }}
                      className="overflow-hidden"
                    >
                      <p className="pt-3 text-xs font-sans font-light text-[#1E1D1C]/80 leading-relaxed">
                        {product.returnsInfo}
                      </p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
